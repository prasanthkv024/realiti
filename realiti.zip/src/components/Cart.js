import React from "react";
import { useCart } from "react-use-cart";
import Grid from '@mui/material/Grid';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';

const Cart = (props) => {
  const {
      isEmpty,    
    totalUniqueItems,
    items,
    totalItems,
    cartTotal,
    updateItemQuantity,
    removeItem,
    emptyCart
  } = useCart();

  if (isEmpty) return <h1 className="text-center"> Your cart isEmpty </h1>;
  return (
    <section className="container">
      <div className="row ">
        <div className="col-12">
          <h5>
            {" "}
            Cart ({totalUniqueItems}) total Item :({totalItems})
          </h5>
         

          <Grid container spacing={3}>
          {items.map((item, index) => {
 return(
  <TableContainer >
  <Table sx={{ minWidth: 650 }} aria-label="simple table">
  
    <TableBody>
     
        <TableRow>
          <TableCell component="th" scope="row">
          <img src={item.image} style={{ height: "6rem" }} alt={''}/>
          </TableCell>
          <TableCell >{item.title}</TableCell>
          
          <TableCell >{item.rate}</TableCell>
          <TableCell >{item.price}</TableCell>
          <TableCell >Quantity({item.quantity})</TableCell>
          <TableCell >
          <button
                        onClick={() =>
                          updateItemQuantity(item.id, item.quantity - 1)
                        }
                        className="btn btn-info ms-2"
                      >
                       
                        -
                      </button>
          </TableCell>
          <TableCell >
          <button
                        onClick={() =>
                          updateItemQuantity(item.id, item.quantity + 1)
                        }
                        className="btn btn-info ms-2"
                      >
                        
                        +
                      </button>
          </TableCell>
          <TableCell >
          <button
                        onClick={() => removeItem(item.id)}
                        className="btn btn-danger ms-2"
                      >
                       
                        RemoveItem
                      </button>
          </TableCell>
        </TableRow>
     
    </TableBody>
  </Table>
</TableContainer>


 
 

 ) })}
  
</Grid> 

          <div className="col-auto ms-auto">
            <h2> total price: {cartTotal} </h2>
          </div>
        </div>
        <div className="col-auto mb-2">
          <button onClick={() => emptyCart()} className="btn btn-danger ms-2">
            Clear Cart
          </button>
          <button  className="btn btn-primary ms-2">
            Buy Now
          </button>
        </div>
      </div>
    </section>
  );
};

export default Cart;
