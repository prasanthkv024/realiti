import React from 'react';
import data from './data.json';
import ProductsCard from './ProductsCard';
import Grid from '@mui/material/Grid';
import "bootstrap/dist/css/bootstrap.min.css";

function Product(props) {
  
    return (
        <div>
          
            <Grid container spacing={2}>
                    {console.log(data,"data")}
             {data && data.map((item, index) => {
            return (
              <Grid item xs={3} >
              <ProductsCard
              image={item.image}
                price={item.price}
                title={item.title}
               
                
                item={item}
                key={index}
                rate={item.rating.rate}
              />
            
              
              </Grid>
              
            );
          })}
          
              </Grid>
              

              
        </div>
    );
}

export default Product;