import React, { useState,useEffect } from 'react';
import Card from '@mui/material/Card';
import CardMedia from '@mui/material/CardMedia';
import Grid from '@mui/material/Grid';
import { useCart } from "react-use-cart";
import Button from '@mui/material/Button';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent'; 
import Typography from '@mui/material/Typography';
import "bootstrap/dist/css/bootstrap.min.css";
import { FaStar ,FaRupeeSign} from "react-icons/fa";
function ProductsCard(props) {
   
    const { addItem,removeItem } = useCart();
    
    
    
    return (
        <div>
    <div className='container mt-5'>
        <div className='row'>
            <div className='col-md-12'>
            <Card >
                                  <CardMedia
                              component="img"
                              height= "300"
                              image={props.image}
                              alt="green iguana"
                             
                            />
                            <CardContent >
                            <Typography variant="body2" color="text.secondary" style={{ width: '100%', height: 80 }} >
                            <p>{props.title}</p>
                            
                           
                            </Typography>
                            <Grid container justifyContent="space-between">
 
 <Grid item xs={4}>
 <Typography variant="body2" color="text.secondary" >
                            <p><FaRupeeSign />{props.price}</p>
                            
                           
                            </Typography>
 </Grid>
 <Grid item xs={4}>
 <Typography variant="body2" color="text.secondary" >
                            <p><FaStar/>{props.rate}</p>
                            
                           
                            </Typography>
 </Grid>
 
</Grid>
                 
                            </CardContent>
                                  
                                  
                                  
                                  <CardActions>
                                     <Button size="small" onClick={() => addItem(props.item) }>Add cart</Button>
                                   </CardActions>
                                   </Card>
            </div>
        </div>
    </div>
           
           
                                 
                   
 
  


        </div>
    );
}






export default ProductsCard;