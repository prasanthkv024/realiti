import React from 'react';
import Cart from './Cart';
import Product from './Product';
import { CartProvider } from "react-use-cart";
function CartView(props) {
    return (
        <div>
            <CartProvider>
                <Cart />
            </CartProvider>
        </div>
    );
}

export default CartView;