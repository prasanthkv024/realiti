import logo from './logo.svg';
import './App.css';
import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";
import Home from './Home';
import Cart from './components/Cart';
import CartView from './components/CartView';

function App() {
  return (
    <div>
      <BrowserRouter>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/CartView" element={<CartView />} />
      
      
      
    </Routes>
  </BrowserRouter>
    </div>
  );
}

export default App;
