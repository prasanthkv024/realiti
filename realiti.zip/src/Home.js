import React from 'react';
import Header from './globalcomponents/Header';
import Products from './components/ProductsCard';
import { CartProvider } from "react-use-cart";
import Product from './components/Product';
import Cart from './components/Cart';

function Home(props) {
    return (
        <div>
            
            <CartProvider>
            <Header/>
           
            <Product />
           
            
            </CartProvider>
        </div>
    );
}

export default Home;